export class EMItypes {
    EMItype_id:number;
    EMI_key:string;
    EMI_tenure:number;
}

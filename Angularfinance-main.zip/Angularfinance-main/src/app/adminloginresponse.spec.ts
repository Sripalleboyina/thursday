import { Adminloginresponse } from './adminloginresponse';

describe('Adminloginresponse', () => {
  it('should create an instance', () => {
    expect(new Adminloginresponse()).toBeTruthy();
  });
});

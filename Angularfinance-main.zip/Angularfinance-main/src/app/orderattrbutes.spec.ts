import { Orderattrbutes } from './orderattrbutes';

describe('Orderattrbutes', () => {
  it('should create an instance', () => {
    expect(new Orderattrbutes()).toBeTruthy();
  });
});

import { Logincredentials } from './logincredentials';

describe('Logincredentials', () => {
  it('should create an instance', () => {
    expect(new Logincredentials()).toBeTruthy();
  });
});

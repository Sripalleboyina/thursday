import { Loginres } from './loginres';

describe('Loginres', () => {
  it('should create an instance', () => {
    expect(new Loginres()).toBeTruthy();
  });
});

import { EMItypes } from './emitypes';

describe('EMItypes', () => {
  it('should create an instance', () => {
    expect(new EMItypes()).toBeTruthy();
  });
});

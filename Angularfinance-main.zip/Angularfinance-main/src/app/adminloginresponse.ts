export class Adminloginresponse {
    StatusCode:number;
    Message:string;
    Admin_Username:string;

}

export class Customer {
    customer_id:number;
    customer_name: string;
    user_name: string;
    user_password:string;
    phone_number: string;
    user_email: string;
    user_address:String;
    bank_name:number;
    IFSC_code:number;
    account_number: number;
    cardtype_id:number;
    haspaid: boolean;
    isapproved:boolean;
    pan_number:string;
    customer_dob:Date;
}

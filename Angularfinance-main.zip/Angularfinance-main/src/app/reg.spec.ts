import { Reg } from './reg';

describe('Reg', () => {
  it('should create an instance', () => {
    expect(new Reg()).toBeTruthy();
  });
});

export class Loginres {
    StatusCode:number;
    Message:string;
    CustomerId:number;
}

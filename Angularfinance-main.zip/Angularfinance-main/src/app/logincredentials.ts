export class Logincredentials {
    user_name:string;
    user_password:string;
}

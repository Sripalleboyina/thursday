export class Product {
    product_id:number;
    product_name:string;
    product_price:number;
    product_image:string;
    product_details:string;
}

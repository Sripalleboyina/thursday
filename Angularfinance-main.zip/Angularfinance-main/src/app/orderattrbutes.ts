export class Orderattrbutes {
    customer_id:number;
    product_id:number;
   EMItype_id:number;
}

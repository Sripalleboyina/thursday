﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace finance_trial4.Models
{
    public class Logincredentials
    {
        public string user_name { get; set; }
        public string user_password { get; set; }
    }
}
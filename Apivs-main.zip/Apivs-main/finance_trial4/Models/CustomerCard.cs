﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace finance_trial4.Models
{
    public class CustomerCard
    {
        public int customer_id { get; set; }
        public decimal total_limit { get; set; }
        public int EMIcard_validity { get; set; }


    }
}

   
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace finance_trial4.Models
{
    public class LoginResponseModel1
    {
        public int StatusCode { get; set; }

        public string Message { get; set; }

        public string Admin_username { get; set; }
    }
}